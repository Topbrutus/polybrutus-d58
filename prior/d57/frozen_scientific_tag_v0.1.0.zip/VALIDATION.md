# Polybrutus D57 exact reproducibility and public release protocol

1. Authentically read original D56 frozen scientific v0.1.0 peeled commit e43dc979e9c7201a82ccb1e6cd4b94560dac3a34, DOI 10.5281/zenodo.24430886, entire source original ZIP SHA256 0af99ac8194e9a65a45fee716b790395820caa939d7ca941812739f73c3b6509 and parent certificate SHA256 ff838ccf905817d20fd789ce13f267bb316287475773330473ecdd76fe573cdc. Both programs validate ZIP SHA/CRC, byte-identical original cert and old labels.
2. Verify 62 unit points and all 1891 exact rational labelled squared-distance pairs, 1830 old D56 pair values, 61 new squared distances 2R², Gram PSD and centered affine rank 57.
3. Independent \`fractions.Fraction\` implementation without importing SymPy Gram, complete label comparison, exact independently selected weighted graph eigenspace multiplicities 31 x51, 61/2 x4.
4. Reject corrupted pair, duplicate new point, tilted nonorthogonal unit point, histogram-preserving label permutation, ensure both programs generate the identical deterministic certificate.
5. Require three GitHub Actions successes (main science, frozen scientific tag, main post DOI), each reruns both programs, certificate diff, metadata keywords and bibliography checks.
6. Publish three Zenodo source tag ZIP, two-page PDF and certificate JSON originals with public MD5, sizes and names matching local SHA256 verified originals; nine current D57 keywords, structured isDerivedFrom direct D56 DOI, two separate references D56 and historic D7 DOI 10.5281/zenodo.24407952.
7. Preserve prior original sources and disclose historical D47/D46 mistaken grandparent textual SHA without modifying old bytes. Avoid unwarranted physics and new universal theorem claims.

    python -m pip install sympy==1.14.0
    python src/verify_d57.py
    python tests/independent_d57.py
    python src/check_zenodo_metadata.py
