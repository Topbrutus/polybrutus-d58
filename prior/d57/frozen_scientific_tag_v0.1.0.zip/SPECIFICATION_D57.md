# Polybrutus D57 — exact 62-point labelled Euclidean squared-distance metric

**Sole direct original parent:** Topbrutus/polybrutus-d56@v0.1.0, peeled scientific Git tag commit \`e43dc979e9c7201a82ccb1e6cd4b94560dac3a34\`, public Zenodo DOI 10.5281/zenodo.24430886, complete frozen scientific source ZIP SHA256 \`0af99ac8194e9a65a45fee716b790395820caa939d7ca941812739f73c3b6509\`, original parent certificate SHA256 \`ff838ccf905817d20fd789ce13f267bb316287475773330473ecdd76fe573cdc\`.

## Exact orthogonal norm-one conservative extension

Embed all 61 predecessor unit vectors p_i as q_i=(p_i,0) and append perpendicular norm-one vector q_62. All C(61,2)=1830 original labelled squared distances remain exactly conserved. Every one of 61 new squared distances equals 2R², totaling C(62,2)=1891 unordered labelled pairs.

Define explicit rational Gram G as an orthogonal sum of seven canonical norm-one points of rank 3, a centered regular five-point unit simplex of rank 4 with mutual inner products -1/4, and **50** independent mutually perpendicular norm-one axes. G=XXᵀ is PSD, has unit diagonal and rank **3+4+50=57**.

With D_ii=0, D_ij=2-2G_ij, H=I-11ᵀ/62, the centered Euclidean Gram B=-(HDH)/2=HGH is PSD of exact rank **57**. The inherited antipodal canonical point pair puts the origin in the affine hull. Therefore the metric's minimum affine Euclidean realization dimension is 57 (58 coordinate storage).

Exact histogram for R=1, k=4d²/R²: 4:6, 7:2, 8:1860, 9:3, 10:10, 12:6, 13:2, 16:2, total 1891. Exact sum of all squared pair distances R=1: **15175/4**.

## Separately freely stipulated ideal weighted graph

Choose scalar masses 1 at all points, complete symmetric weights w_ij=1/d_ij². New vertex connects each of the 61 earlier points by ideal edge weight 1/2. The Laplacian block is L57=[[L56+I61/2,-1_61/2],[-1_61ᵀ/2,61/2]].

Characteristic polynomial recurrence: chi62(z)=z(z-31)chi61(z-1/2)/(z-1/2).
With original f6(z)=chiP7(z)/z, the selected-model closed form:
chi62(z)=z(z-31)^51(z-61/2)^4*f6(z-55/2).

Exact rational eigenspace rank-nullity proves eigenvalue **31 multiplicity 51** and **61/2 multiplicity 4**. These are dimensionless modes of the chosen graph, not physical frequencies.

**References:** direct D56 DOI 10.5281/zenodo.24430886 and historical D7 DOI 10.5281/zenodo.24407952.
