# Complete original Polybrutus D56 frozen scientific tag and certificate

- Direct parent frozen source tag: https://github.com/Topbrutus/polybrutus-d56/tree/v0.1.0, actual peeled Git commit e43dc979e9c7201a82ccb1e6cd4b94560dac3a34.
- Parent public DOI 10.5281/zenodo.24430886.
- Full original scientific ZIP \`frozen_scientific_tag_v0.1.0.zip\`: **3420998 bytes**, **32 entries**, ZIP CRC PASS, SHA256 \`0af99ac8194e9a65a45fee716b790395820caa939d7ca941812739f73c3b6509\`.
- Exact original \`results/certificate_d56.json\`: **138831 bytes**, SHA256 \`ff838ccf905817d20fd789ce13f267bb316287475773330473ecdd76fe573cdc\`.
- All earlier complete source archives remain nested byte-identically. Historical original D47 certificate D46 grandparent commit text mismatch disclosed and never silently corrected.
