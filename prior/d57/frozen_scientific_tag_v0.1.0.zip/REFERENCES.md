# Polybrutus D57 — references and provenance

**Earlier same-author works, not independent human peer review:**

[1] St-Pierre, Gabriel (2026). *Polybrutus 56D: Exact 61-Point Euclidean Metric and Fiftyfold Ideal Graph Mode*. Zenodo DOI [10.5281/zenodo.24430886](https://doi.org/10.5281/zenodo.24430886), direct immutable scientific parent. Frozen GitHub tag [Polybrutus D56 v0.1.0](https://github.com/Topbrutus/polybrutus-d56/tree/v0.1.0), peeled commit e43dc979e9c7201a82ccb1e6cd4b94560dac3a34.

[2] St-Pierre, Gabriel (2026). *Polybrutus 7D: An Exact Twelve-Point Orthogonal Completion, the 12-35-37 Identity, and an Oscillator Model*. Zenodo DOI [10.5281/zenodo.24407952](https://doi.org/10.5281/zenodo.24407952), historical reference, not immediate D57 parent.

[3] St-Pierre, Gabriel (2026). Complete original Polybrutus D56 frozen scientific Git tag v0.1.0, https://github.com/Topbrutus/polybrutus-d56/tree/v0.1.0, original ZIP SHA256 \`0af99ac8194e9a65a45fee716b790395820caa939d7ca941812739f73c3b6509\`, byte-identically embedded in D57 ZIP.

Zenodo contract: nine \`fifty-seven\`/\`fifty-onefold\` keywords; structured \`isDerivedFrom\` DOI D56 10.5281/zenodo.24430886; separate text references D56 and D7.
