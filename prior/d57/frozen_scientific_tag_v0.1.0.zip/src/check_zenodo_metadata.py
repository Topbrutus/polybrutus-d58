#!/usr/bin/env python3
from pathlib import Path
import json
R=Path(__file__).resolve().parents[1]
c=json.loads((R/'results/certificate_d57.json').read_text('utf8'))
m=json.loads((R/'publication/zenodo_metadata_blueprint.json').read_text('utf8'))
assert c['status']=='PASS' and c['dimension']==m['scientific_dimension']==57
assert c['vertices']==m['norm_one_vertices']==62
assert c['pairs']==m['exact_labelled_squared_pairs']==1891
assert c['affine_rank']==c['centered_gram_rank']==57
assert c['eigenvalue_31_multiplicity']==m['model_eigenvalue_31_multiplicity']==51
assert c['eigenvalue_61_over_2_multiplicity']==m['model_eigenvalue_61_over_2_multiplicity']==4
assert c['parent_tag_commit']=='e43dc979e9c7201a82ccb1e6cd4b94560dac3a34'
assert c['parent_doi']==m['scientific_parent_doi']=='10.5281/zenodo.24430886'
assert m['related_identifiers']==[{'identifier':'10.5281/zenodo.24430886','relation':'isDerivedFrom','resource_type':'publication-preprint','scheme':'doi'}]
assert len(m['keywords'])==9
assert 'affine Euclidean dimension fifty-seven' in m['keywords']
assert 'fifty-onefold ideal eigenvalue' in m['keywords']
assert len(m['references'])==2
assert '10.5281/zenodo.24430886' in m['references'][0]
assert '10.5281/zenodo.24407952' in m['references'][1]
assert not any(x in str(m['keywords']) for x in ('fifty-six','fiftyfold','fifty-eight','fifty-twofold'))
note=(R/'publication/POLYBRUTUS_57D_NOTE.md').read_text('utf8')
assert all(x in note for x in ('## References','10.5281/zenodo.24430886','10.5281/zenodo.24407952'))
print('D57_CURRENT_9_KEYWORDS_STRUCTURED_DIRECT_PARENT_AND_SEPARATE_D56_D7_REFERENCES_PASS')
