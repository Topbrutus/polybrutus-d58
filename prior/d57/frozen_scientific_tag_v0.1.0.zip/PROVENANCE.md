# Polybrutus D57 — source lineage, original immutable archives and AI disclosure

**Human scientific author:** Gabriel St-Pierre, independent researcher.
**Material AI assistance:** OpenAI ChatGPT (Astra) assisted the two exact rational programs, manuscript and public release. AI is not a scientific author.

**Exclusive direct scientific parent:** Topbrutus/polybrutus-d56@v0.1.0, peeled scientific tag commit \`e43dc979e9c7201a82ccb1e6cd4b94560dac3a34\`, DOI 10.5281/zenodo.24430886. Entire original frozen source \`prior/d56/frozen_scientific_tag_v0.1.0.zip\`: **3420998 bytes, 32 entries, CRC PASS**, SHA256 \`0af99ac8194e9a65a45fee716b790395820caa939d7ca941812739f73c3b6509\`. All earlier complete original source ZIPs remain nested byte-identically. Original certificate \`prior/d56/results/certificate_d56.json\`: **138831 bytes**, SHA256 \`ff838ccf905817d20fd789ce13f267bb316287475773330473ecdd76fe573cdc\`, preserved unchanged. Both rational D57 implementations validate original ZIP SHA/CRC, original certificate bytes and all 1830 inherited labels.

**Historical documentary discrepancy:** original D47 certificate has an incorrect textual D46 grandparent Git commit label, disclosed since D48; all historical originals remain unchanged. D57 authenticates direct immediate D56 source independently. Text CRLF/LF differences between original archive and Git blobs only normalized during comparison, with original source never rewritten.

Zenodo structured \`isDerivedFrom\` to direct D56 DOI 10.5281/zenodo.24430886, two separate D56/D7 references to 10.5281/zenodo.24407952.
**Scope:** This verifies one constructed synthetic exact Euclidean labelled metric and one separately stipulated dimensionless ideal weighted graph. It does not establish new physical spacetime dimensions, observed hertz, particles, a novel universal mathematical theorem or independent human peer review.
