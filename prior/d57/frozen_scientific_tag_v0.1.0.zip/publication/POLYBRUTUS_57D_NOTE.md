# Polybrutus 57D: Exact 62-point Euclidean metric and a fifty-onefold ideal graph mode

**Gabriel St-Pierre** - Independent researcher
**21 November 2026**
**Exact mathematical preprint / reproducible synthetic case study**
**AI disclosure:** OpenAI ChatGPT (Astra) materially assisted two independently implemented rational programs, verification, scientific manuscript and controlled publication. AI is not the scientific author.

## Abstract

We construct an exact synthetic Euclidean squared-distance metric on 62 norm-one labelled points by adjoining a perpendicular norm-one point to the original immutable Polybrutus D56 [1]. Every one of 1830 original predecessor labelled squared distances remains unchanged; 61 new distances squared each equal 2R², yielding 1891 unordered labelled pairs. The exact rational centered Euclidean Gram is PSD with rank 57, proving minimum affine Euclidean realization dimension 57 for this constructed metric. In a separately chosen ideal scalar-unit-mass complete weighted graph with w_ij=1/d_ij², exact rational Laplacian eigenspace ranks give eigenvalue 31 multiplicity 51 and 61/2 multiplicity 4. Two independent implementations verify all 1891 labels, all 1830 old labels, centered Gram rank, spectral nullities and complete authentic parent source. We make no physical observation claims.

## 1. Immediate immutable parent and conservative orthogonal extension

Our sole direct predecessor is St-Pierre, Polybrutus D56 [1], DOI 10.5281/zenodo.24430886, exact frozen scientific GitHub tag Topbrutus/polybrutus-d56@v0.1.0 with actual peeled commit e43dc979e9c7201a82ccb1e6cd4b94560dac3a34. Its **entire original frozen source ZIP** remains embedded byte-identically at prior/d56/frozen_scientific_tag_v0.1.0.zip, 3420998 bytes and 32 entries, CRC PASS, SHA256 0af99ac8194e9a65a45fee716b790395820caa939d7ca941812739f73c3b6509, with all earlier frozen source archives still nested unchanged. Original D56 certificate prior/d56/results/certificate_d56.json is likewise preserved byte-identically SHA256 ff838ccf905817d20fd789ce13f267bb316287475773330473ecdd76fe573cdc. Both independent verifiers authenticate ZIP SHA, CRC, original certificate bytes and every old labelled pair value.

Let p_i (i=1,...,61) be predecessor norm-one Euclidean points. Embed q_i=(p_i,0) into a new Euclidean coordinate space and append q_62, one perpendicular norm-one vector. All C(61,2)=1830 inherited labelled squared distances remain exactly the same; for each new pair ||q_62-q_i||²=2R². Thus C(62,2)=1891=1830+61 unordered labelled squared distances. This is a deliberately constructed mathematical metric, not physical spacetime evidence.

## 2. Exact rational PSD Gram and exhaustive labelled-distance metric

Construct a rational Gram G as orthogonal block sum of seven canonical norm-one points rank 3, an independent centered regular five-unit simplex rank 4 with mutual dot products -1/4, and 50 independent mutually perpendicular norm-one axes. Thus G=XXᵀ is PSD with unit diagonal and rank 3+4+50=57. Define D_ii=0, D_ij=2-2G_ij and H=I-11ᵀ/62. The centered Gram B=-(HDH)/2=HGH is PSD with exact rank 57. The inherited antipodal canonical point pair ensures the origin lies in the affine hull; minimum affine Euclidean realization dimension for this specified metric is therefore 57 (58 coordinate storage).

At R=1, all labelled pair values produce histogram of normalized squared distance k=4d²/R²: 4:6, 7:2, 8:1860, 9:3, 10:10, 12:6, 13:2, 16:2, totaling 1891 pairs. Their exact sum is 15175/4. The original 1830 predecessor labelled distances are authenticated and compared one by one; a matching histogram alone would not prove conservative extension.

## 3. Separately stipulated ideal graph and eigenvalue multiplicities

Independently choose unit scalar masses and complete-graph positive edge weights w_ij=1/d_ij². The new orthogonal unit point joins each of 61 old vertices at graph weight 1/2. The ideal Laplacian block L57=[[L56+I61/2,-1_61/2],[-1_61ᵀ/2,61/2]]. Its characteristic polynomial recurrence chi62(z)=z(z-31)chi61(z-1/2)/(z-1/2). With inherited seven-point factor f6(z)=chiP7(z)/z, the chosen-model closed form is chi62(z)=z(z-31)^51(z-61/2)^4*f6(z-55/2).

Exact rational eigenspace ranks independently prove eigenvalue 31 multiplicity 51 and eigenvalue 61/2 multiplicity 4. These are dimensionless modes of a freely specified ideal graph, not measured acoustic/electromagnetic hertz, particles or spacetime dimensions.

## 4. Independent exact software verification and adversarial controls

Primary src/verify_d57.py constructs G with SymPy rationals, computes all 1891 labelled squared distances, centered Gram rank, graph nullities, and original D56 source ZIP SHA/CRC plus certificate bytes and all 1830 predecessor labels. Independent tests/independent_d57.py uses separately defined Python fractions.Fraction distance rules without importing the primary Gram construction, independently recomputes all labels, parent comparison, centered Gram and graph nullity. Both yield the identical deterministic results/certificate_d57.json SHA256.

Four primary negative controls reject a corrupted new pair, duplicate final unit point, nonperpendicular tilted norm-one new point, and a histogram-preserving label permutation changing pair labels. Independent checker also detects damaged pairs and label permutations.

The original older D47 certificate carries an inaccurate text label for the D46 grandparent Git commit, disclosed since D48; all ancestor original source bytes remain unchanged. Our direct D56 frozen tag and full source archive are independently authenticated.

## 5. Reproducibility, bibliographic contract and scientific boundaries

With Python 3.12 and sympy==1.14.0, all exact calculations can be rerun. Orthogonal norm-one Euclidean extensions and weighted complete-graph joins are standard constructions. This preprint verifies one synthetic metric and a separately chosen ideal dimensionless graph, not a new universal theorem, experimentally observed hertz, physical extra dimensions, particles, a physical discovery or independent human peer review.

Zenodo metadata must carry exactly nine current D57 keywords including fifty-seven and fifty-onefold, a structured isDerivedFrom relation to direct D56 DOI 10.5281/zenodo.24430886, and a distinct two-entry references field for D56 [1] and historical Polybrutus D7 [2]. All three published original source ZIP, PDF and certificate JSON require public API file names, MD5 and byte-size agreement against local SHA256.

## References

[1] St-Pierre, Gabriel (2026). Polybrutus 56D: Exact 61-Point Euclidean Metric and Fiftyfold Ideal Graph Mode. Zenodo DOI 10.5281/zenodo.24430886. https://doi.org/10.5281/zenodo.24430886

[2] St-Pierre, Gabriel (2026). Polybrutus 7D: An Exact Twelve-Point Orthogonal Completion, the 12-35-37 Identity, and an Oscillator Model. Zenodo DOI 10.5281/zenodo.24407952. https://doi.org/10.5281/zenodo.24407952

[3] St-Pierre, Gabriel (2026). Full original Polybrutus D56 frozen scientific GitHub source tag v0.1.0, https://github.com/Topbrutus/polybrutus-d56/tree/v0.1.0, scientific peeled commit e43dc979e9c7201a82ccb1e6cd4b94560dac3a34. Entire ZIP preserved unchanged.
