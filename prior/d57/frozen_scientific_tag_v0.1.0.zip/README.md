# Polybrutus 57D — exact 62-point Euclidean metric and fifty-onefold ideal graph mode

**Human scientific author:** Gabriel St-Pierre, independent researcher.
**Material AI assistance:** OpenAI ChatGPT (Astra) developed and tested independent exact programs, manuscript and controlled release; AI is not a scientific author.

## Exact synthetic Euclidean metric and separately chosen ideal graph

- **62** norm-one points, **1891 / 1891** unordered labelled exact rational squared-distance pairs.
- **1830 / 1830** original predecessor D56 labelled squared distances preserved; **61** new squared distances exactly **2R²**.
- Rational Gram PSD and centered Euclidean Gram PSD exact **affine rank 57**, minimum Euclidean dimension for this specified synthetic metric; 58 coordinate storage.
- Exact histogram k=4d²/R², R=1: 4:6, 7:2, 8:1860, 9:3, 10:10, 12:6, 13:2, 16:2. Total sum of pair squared distances R=1: **15175/4**.
- **Separately stipulated** ideal unit-scalar-mass complete weighted graph w_ij=1/d_ij²: dimensionless Laplacian eigenvalue **31 multiplicity 51**, and **61/2 multiplicity 4**. Not measured hertz.
- Two independently implemented rational pair rules, four primary adversarial negative controls, original full D56 frozen scientific Git tag ZIP SHA-256/CRC and byte-identical original D56 certificate verification.

Reproduce (Python 3.12, SymPy 1.14.0):

    python -m pip install sympy==1.14.0
    python src/verify_d57.py
    python tests/independent_d57.py
    python src/check_zenodo_metadata.py

Both programs reproduce identical deterministic certificate \`results/certificate_d57.json\`. GitHub CI runs both implementations, compares the deterministic certificate and verifies Zenodo metadata and bibliography.

## Sole original frozen scientific parent

[Polybrutus D56 v0.1.0](https://github.com/Topbrutus/polybrutus-d56/tree/v0.1.0), actual peeled Git commit \`e43dc979e9c7201a82ccb1e6cd4b94560dac3a34\`, DOI [10.5281/zenodo.24430886](https://doi.org/10.5281/zenodo.24430886). Its **entire original source ZIP**, including all earlier complete original nested frozen source ZIPs, is preserved byte-identically at \`prior/d56/frozen_scientific_tag_v0.1.0.zip\`, SHA256 \`0af99ac8194e9a65a45fee716b790395820caa939d7ca941812739f73c3b6509\`. The original D56 certificate is copied byte-identically SHA256 \`ff838ccf905817d20fd789ce13f267bb316287475773330473ecdd76fe573cdc\`.

Zenodo contract: nine D57 keywords (\`fifty-seven\`, \`fifty-onefold\`), structured \`isDerivedFrom\` direct D56 DOI 10.5281/zenodo.24430886, separate references D56 and historical D7 DOI 10.5281/zenodo.24407952.

[Specification](SPECIFICATION_D57.md) | [proof](PREUVE_D57.md) | [source provenance](PROVENANCE.md) | [bibliography](REFERENCES.md) | [two-page scientific note](publication/POLYBRUTUS_57D_NOTE.pdf).

**Scope:** This verifies one constructed synthetic exact Euclidean labelled metric and one separately stipulated dimensionless ideal weighted graph. It does not establish new physical spacetime dimensions, observed hertz, particles, a novel universal mathematical theorem or independent human peer review.
**MIT software; CC BY 4.0 manuscript.**
